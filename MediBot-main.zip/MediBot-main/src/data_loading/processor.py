import pandas as pd
from langchain_core.documents import Document

def load_and_preprocess_data(raw_dir: str):
    """
    Loads raw CSV files, merges them, and creates a list of Langchain Documents
    representing the symptoms, description, severity, and precautions of diseases.
    """
    df_disease = pd.read_csv(f"{raw_dir}/dataset.csv")
    df_severity = pd.read_csv(f"{raw_dir}/Symptom-severity.csv")
    df_desc = pd.read_csv(f"{raw_dir}/symptom_Description.csv")
    df_prec = pd.read_csv(f"{raw_dir}/symptom_precaution.csv")

    # Clean symptom strings
    for col in df_disease.columns:
        if 'Symptom' in col:
            df_disease[col] = df_disease[col].apply(lambda x: x.strip().replace('_', ' ') if pd.notnull(x) else x)
    df_severity['Symptom'] = df_severity['Symptom'].apply(lambda x: x.strip().replace('_', ' ') if pd.notnull(x) else x)

    # Group by disease to get all associated symptoms
    disease_symptoms = {}
    for idx, row in df_disease.iterrows():
        disease = row['Disease'].strip()
        symptoms = [str(x) for x in row[1:] if pd.notnull(x)]
        if disease not in disease_symptoms:
            disease_symptoms[disease] = set()
        disease_symptoms[disease].update(symptoms)

    # Creating dictionaries for rapid lookup
    desc_dict = dict(zip(df_desc['Disease'].str.strip(), df_desc['Description']))
    
    prec_cols = ['Precaution_1', 'Precaution_2', 'Precaution_3', 'Precaution_4']
    prec_dict = {}
    for idx, row in df_prec.iterrows():
        disease = str(row['Disease']).strip()
        precs = [str(p).strip() for p in row[prec_cols] if pd.notnull(p)]
        prec_dict[disease] = precs

    documents = []
    for disease, symptoms in disease_symptoms.items():
        symptoms_list = list(symptoms)
        symptoms_str = ", ".join(symptoms_list)
        desc = desc_dict.get(disease, "Description not available.")
        precs = prec_dict.get(disease, [])
        prec_str = ", ".join(precs) if precs else "No specific precautions available."
        
        # The page_content is the text that is vectorized and searched against.
        page_content = f"Disease: {disease}\nSymptoms: {symptoms_str}\nDescription: {desc}\nPrecautions: {prec_str}"
        
        doc = Document(
            page_content=page_content,
            metadata={
                "disease": disease,
                "symptoms": symptoms_list,
                "description": desc,
                "precautions": precs
            }
        )
        documents.append(doc)
        
    return documents, df_severity
