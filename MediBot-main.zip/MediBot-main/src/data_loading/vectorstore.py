import os
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from src.data_loading.processor import load_and_preprocess_data

def build_vector_store(raw_dir="data/raw", persist_dir="data/faiss_index"):
    print("Loading and preprocessing data...")
    documents, _ = load_and_preprocess_data(raw_dir)
    
    print("Initializing embeddings model...")
    # Leveraging a lightweight huggingface CPU embeddings model
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    
    print("Building FAISS index...")
    vectorstore = FAISS.from_documents(documents, embeddings)
    
    print(f"Saving vectorstore to {persist_dir}...")
    vectorstore.save_local(persist_dir)
    return vectorstore

def get_vector_store(persist_dir="data/faiss_index"):
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    return FAISS.load_local(persist_dir, embeddings, allow_dangerous_deserialization=True)

if __name__ == "__main__":
    import sys
    # For running as a module/script
    root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    bvs = build_vector_store(
        raw_dir=os.path.join(root_dir, "data", "raw"),
        persist_dir=os.path.join(root_dir, "data", "faiss_index")
    )
    print("Success")
