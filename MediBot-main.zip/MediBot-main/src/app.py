import os
import gradio as gr
from dotenv import load_dotenv

# Let's load the env correctly
load_dotenv()

from langchain_google_genai import ChatGoogleGenerativeAI
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

from src.agents.tools import medibot_tools
from src.data_loading.vectorstore import build_vector_store

os.environ['LANGCHAIN_TRACING_V2'] = "false"
os.environ['USER_AGENT'] = "medibot/1.0"

# Enable verbose logging to see exactly what the AI is thinking!
import langchain
langchain.debug = True

SYSTEM_PROMPT = (
    "You are MediBot, an AI-powered Symptom Checker and Medical Assistant. "
    "You must assist users with predicting probable diseases, assessing symptom severity, "
    "providing explanations, and suggesting preventive care. \n"
    "ALWAYS use the provided tools to fetch accurate information. NEVER guess medical advice. "
    "Workflow:\n"
    "1. First, use `severity_tool` to assess the urgency of the symptoms.\n"
    "2. Second, use `diagnosis_tool` to predict the disease.\n"
    "3. Then, you can provide `description_tool` and `precaution_tool` if asked or to be helpful.\n"
    "Always formulate a comprehensive and empathetic response."
)

def init_app():
    # Make sure FAISS index exists
    root_dir = os.path.dirname(os.path.dirname(__file__))
    faiss_dir = os.path.join(root_dir, "data", "faiss_index")
    if not os.path.exists(faiss_dir):
        print("FAISS index not found. Building it now...")
        build_vector_store(
            raw_dir=os.path.join(root_dir, "data", "raw"),
            persist_dir=faiss_dir
        )

    # Note: Expects GOOGLE_API_KEY to be set in .env
    llm = ChatGoogleGenerativeAI(model="gemini-flash-latest", temperature=0)

    # Initialize cleanly without version-specific kwargs
    agent_executor = create_react_agent(llm, tools=medibot_tools)
    return agent_executor

chat_history = []
agent_executor = None

def chatbot_interface(user_message, history):
    global agent_executor
    global chat_history
    
    if agent_executor is None:
        try:
            agent_executor = init_app()
        except Exception as e:
            return f"Error initializing agent. Please check your API keys inside .env file. Details: {str(e)}"
            
    # Safely inject the system prompt across any LangGraph version
    if not chat_history:
        chat_history.append(SystemMessage(content=SYSTEM_PROMPT))
        
    chat_history.append(HumanMessage(content=user_message))
    
    try:
        response = agent_executor.invoke({
            "messages": chat_history
        })
        bot_message = response["messages"][-1].content
    except Exception as e:
        bot_message = f"Error during inference: {str(e)}"
        
    chat_history.append(AIMessage(content=bot_message))
    
    return bot_message

def main():
    print("Starting MediBot UI...")
    
    demo = gr.ChatInterface(
        fn=chatbot_interface,
        title="MediBot 🩺: Your AI Medical Assistant",
        description="Describe your symptoms naturally, and I will assess the severity, predict probable conditions, and provide precautions. *Disclaimer: AI predictions are for informational purposes and not a substitute for a doctor.*"
    )
    
    demo.launch(server_name="127.0.0.1", server_port=7860, share=False)

if __name__ == "__main__":
    main()
