from langchain.tools import tool
from src.agents.diagnosis import get_diagnosis
from src.agents.severity import get_severity_assessment
from src.agents.description import get_disease_description
from src.agents.precaution import get_disease_precautions

@tool
def diagnosis_tool(symptoms: str) -> str:
    """
    Pass the patient's exact symptoms to this tool to predict the most probable illnesses.
    Input should be a comma-separated list of symptoms. Execute this first to find out the disease.
    """
    return get_diagnosis(symptoms)

@tool
def severity_tool(symptoms: str) -> str:
    """
    Pass the patient's exact symptoms to this tool to assess the urgency and severity of their condition.
    Input should be a comma-separated list of symptoms.
    """
    return get_severity_assessment(symptoms)

@tool
def description_tool(disease_name: str) -> str:
    """
    Pass a specific disease name (identified by diagnosis_tool) to this tool to get an easy-to-understand explanation of the disease.
    """
    return get_disease_description(disease_name)

@tool
def precaution_tool(disease_name: str) -> str:
    """
    Pass a specific disease name (identified by diagnosis_tool) to this tool to get self-care and preventive measure suggestions.
    """
    return get_disease_precautions(disease_name)

medibot_tools = [diagnosis_tool, severity_tool, description_tool, precaution_tool]
