import os
import pandas as pd

_severity_dict = None

def get_severity_assessment(symptoms: str) -> str:
    """
    Assesses the clinical urgency (severity) of the user's symptoms based on documented severity weights.
    """
    global _severity_dict
    if _severity_dict is None:
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        df = pd.read_csv(os.path.join(root_dir, "data", "raw", "Symptom-severity.csv"))
        df['Symptom'] = df['Symptom'].apply(lambda x: x.strip().replace('_', ' ') if pd.notnull(x) else x)
        _severity_dict = dict(zip(df['Symptom'], df['weight']))
        
    symptom_list = [s.strip().lower() for s in symptoms.replace(' and ', ',').split(',')]
    
    total_severity = 0
    matched = []
    
    for symptom in symptom_list:
        for k, v in _severity_dict.items():
            if symptom in k or k in symptom:
                total_severity += v
                matched.append(k)
                break 
                
    if not matched:
        return "Could not compute severity since no standard symptoms were reliably matched. Please monitor your condition cautiously."
        
    avg_severity = total_severity / len(matched)
    
    if avg_severity >= 5.5:
        urgency = "🔴 **HIGH URGENCY!** Your symptoms indicate a potentially severe condition. Please seek immediate professional medical assistance."
    elif avg_severity >= 4.0:
        urgency = "🟠 **Moderate Urgency.** It is highly recommended that you consult a doctor soon."
    else:
        urgency = "🟢 **Low Urgency.** Your symptoms appear mild. Please take rest and monitor yourself, but seek help if things worsen."
        
    return f"Severity Assessment: {urgency}\nIdentified symptoms for this assessment: {', '.join(matched)}"
