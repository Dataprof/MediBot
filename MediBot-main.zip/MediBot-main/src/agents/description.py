import os
import pandas as pd
from typing import Optional

_desc_dict = None

def get_disease_description(disease_name: str) -> str:
    """
    Provides a medically sound, easy-to-understand description of a specific disease.
    """
    global _desc_dict
    if _desc_dict is None:
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        df = pd.read_csv(os.path.join(root_dir, "data", "raw", "symptom_Description.csv"))
        _desc_dict = {str(k).strip().lower(): v for k, v in zip(df['Disease'], df['Description'])}
        
    disease_lower = disease_name.strip().lower()
    
    # Try exact match
    if disease_lower in _desc_dict:
        return f"**{disease_name.title()}**: {_desc_dict[disease_lower]}"
        
    # Try partial match
    for k, v in _desc_dict.items():
        if disease_lower in k or k in disease_lower:
            return f"**{k.title()}**: {v}"
            
    return f"Sorry, I couldn't find a detailed description for '{disease_name}' in my local knowledge base."
