import os
import pandas as pd

_prec_dict = None

def get_disease_precautions(disease_name: str) -> str:
    """
    Suggests preventive measures and self-care recommendations for a specific disease.
    """
    global _prec_dict
    if _prec_dict is None:
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        df = pd.read_csv(os.path.join(root_dir, "data", "raw", "symptom_precaution.csv"))
        _prec_dict = {}
        for _, row in df.iterrows():
            d = str(row['Disease']).strip().lower()
            precs = [str(x).capitalize() for x in row[['Precaution_1', 'Precaution_2', 'Precaution_3', 'Precaution_4']] if pd.notnull(x)]
            _prec_dict[d] = precs
            
    disease_lower = disease_name.strip().lower()
    
    match = None
    if disease_lower in _prec_dict:
        match = disease_lower
    else:
        for k in _prec_dict.keys():
            if disease_lower in k or k in disease_lower:
                match = k
                break
                
    if match:
        precs = _prec_dict[match]
        prec_str = "\n".join([f"- {p}" for p in precs if p.strip() != 'Nan'])
        return f"Suggested precautions/self-care for **{match.title()}**:\n{prec_str}"
        
    return f"Sorry, I couldn't find standardized precautions for '{disease_name}'."
