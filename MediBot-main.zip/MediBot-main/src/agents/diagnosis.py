import os
from src.data_loading.vectorstore import get_vector_store

_vectorstore = None

def get_diagnosis(symptoms: str) -> str:
    """
    Given a natural language string of symptoms, queries the medical knowledge base
    to predict the most probable disease.
    """
    global _vectorstore
    if _vectorstore is None:
        root_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        persist_dir = os.path.join(root_dir, "data", "faiss_index")
        _vectorstore = get_vector_store(persist_dir)
        
    docs = _vectorstore.similarity_search(f"Symptoms: {symptoms}", k=3)
    
    if not docs:
        return "I could not find a matching diagnosis for these symptoms."
        
    response = "Based on your symptoms, here are the most probable conditions:\n"
    for i, doc in enumerate(docs, 1):
        disease = doc.metadata.get('disease', 'Unknown')
        matched_symptoms = ", ".join(doc.metadata.get('symptoms', []))
        response += f"{i}. **{disease}** (Typical symptoms include: {matched_symptoms})\n"
        
    return response + "\n*Disclaimer: I am an AI, not a doctor. Please consult a healthcare professional for an accurate diagnosis.*"
