import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Configuration
RAW_DIR = "data/raw"
PLOT_DIR = "plots"
os.makedirs(PLOT_DIR, exist_ok=True)

def load_data():
    df_disease = pd.read_csv(f"{RAW_DIR}/dataset.csv")
    df_severity = pd.read_csv(f"{RAW_DIR}/Symptom-severity.csv")
    df_desc = pd.read_csv(f"{RAW_DIR}/symptom_Description.csv")
    df_prec = pd.read_csv(f"{RAW_DIR}/symptom_precaution.csv")
    return df_disease, df_severity, df_desc, df_prec

def clean_symptoms(df):
    """Removing trailing/leading whitespaces from all symptom columns"""
    for col in df.columns:
        if 'Symptom' in col:
            df[col] = df[col].apply(lambda x: x.strip() if pd.notnull(x) else x)
    return df

def eda_missing_values(df, name):
    print(f"\n--- Missing Values in {name} ---")
    missing = df.isnull().sum()
    print(missing[missing > 0])
    
    # Plot missing values percentage
    if missing.sum() > 0:
        plt.figure(figsize=(10, 6))
        missing_pct = (missing[missing > 0] / len(df)) * 100
        sns.barplot(x=missing_pct.index, y=missing_pct.values, color='steelblue')
        plt.title(f"Missing Values Percentage in {name}")
        plt.ylabel("Percentage (%)")
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig(f"{PLOT_DIR}/missing_values_{name}.png")
        plt.close()

def main():
    print("Starting EDA for MediBot datasets...")
    df_disease, df_severity, df_desc, df_prec = load_data()
    
    print("\n1. Data Shapes:")
    print("Disease mappings:", df_disease.shape)
    print("Severity mappings:", df_severity.shape)
    print("Descriptions:", df_desc.shape)
    print("Precautions:", df_prec.shape)
    
    # Missing values
    eda_missing_values(df_disease, "dataset")
    eda_missing_values(df_severity, "severity")
    eda_missing_values(df_desc, "Description")
    eda_missing_values(df_prec, "Precaution")
    
    # Clean up string columns in disease dataset
    df_disease = clean_symptoms(df_disease)
    
    # Clean severity spaces
    df_severity['Symptom'] = df_severity['Symptom'].apply(lambda x: x.strip() if pd.notnull(x) else x)
    
    # Correlation analysis of common symptoms vs severity
    # Melt the disease dataset to get unique symptoms per disease
    df_melted = df_disease.melt(id_vars=['Disease'], value_name='Symptom').dropna()
    df_melted['Symptom'] = df_melted['Symptom'].str.strip()
    
    # Count of diseases sharing the same symptom
    symptom_counts = df_melted['Symptom'].value_counts()
    
    plt.figure(figsize=(12, 8))
    sns.barplot(x=symptom_counts.head(20).values, y=symptom_counts.head(20).index, palette='viridis')
    plt.title("Top 20 Most Common Symptoms Across All Diseases")
    plt.xlabel("Frequency")
    plt.ylabel("Symptom")
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/top_20_symptoms.png")
    plt.close()
    
    # Merge with severity
    # Group by disease to get an average "severity index" of a disease
    df_merged = pd.merge(df_melted, df_severity, on='Symptom', how='left')
    disease_severity = df_merged.groupby('Disease')['weight'].mean().sort_values(ascending=False)
    
    plt.figure(figsize=(12, 10))
    sns.barplot(x=disease_severity.head(25).values, y=disease_severity.head(25).index, palette='magma')
    plt.title("Top 25 Diseases by Average Symptom Severity")
    plt.xlabel("Average Severity Weight")
    plt.tight_layout()
    plt.savefig(f"{PLOT_DIR}/disease_avg_severity.png")
    plt.close()

    print("\nEDA Completed successfully. Plots saved to 'plots/' directory.")

if __name__ == '__main__':
    main()
